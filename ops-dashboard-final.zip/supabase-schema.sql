-- Ops Dashboard: Supabase schema
-- Ye SQL Supabase dashboard -> SQL Editor mein run karo (ek baar, project banane ke baad)

create table if not exists ops_state (
  id text primary key default 'main',
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

insert into ops_state (id, data)
values ('main', '{"clients":[],"metrics":[],"finance":[],"audience":[]}'::jsonb)
on conflict (id) do nothing;

alter table ops_state enable row level security;

-- Simple setup: no login, anon key can read/write this one row.
-- (Kisi bhi kisi ko iska link mile to wo data dekh/badal sakta hai -- link private rakho.)
create policy "anon can read ops_state"
  on ops_state for select
  to anon
  using (true);

create policy "anon can update ops_state"
  on ops_state for update
  to anon
  using (true)
  with check (true);

create policy "anon can insert ops_state"
  on ops_state for insert
  to anon
  with check (true);
