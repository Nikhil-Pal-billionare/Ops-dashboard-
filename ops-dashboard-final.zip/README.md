# Ops Dashboard

Client growth tracking + business finance dashboard. Next.js app, data stored
in Supabase (no login, single shared record).

## 1. Supabase setup (5 minutes)

1. Go to https://supabase.com and create a new project (free tier is fine).
2. Once the project is ready, open **SQL Editor** in the left sidebar.
3. Copy the entire content of `supabase-schema.sql` from this repo and run it.
   This creates the `ops_state` table and the access policy.
4. Go to **Project Settings -> API**. Copy two values:
   - **Project URL** (looks like `https://xxxxx.supabase.co`)
   - **anon public** key (a long string under "Project API keys")

## 2. Upload this project to GitHub

1. Create a new empty repository on GitHub (do not add a README there).
2. Upload all files from this folder into that repository
   (GitHub web UI: "Add file" -> "Upload files", drag everything in,
   or use "creating a new file" and paste content one by one if you are
   on mobile and cannot upload folders directly -- in that case use the
   GitHub mobile app's "Add file" option per file, keeping the same
   folder paths shown here).

## 3. Deploy on Vercel

1. Go to https://vercel.com, sign in, click **Add New -> Project**.
2. Import the GitHub repository you just created.
3. Vercel auto-detects Next.js -- leave build settings as default.
4. Before clicking Deploy, open **Environment Variables** and add:
   - `NEXT_PUBLIC_SUPABASE_URL` = your Project URL from step 1
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = your anon key from step 1
5. Click **Deploy**. Wait 1-2 minutes.
6. Your dashboard is live at the Vercel URL. Every device that opens
   this URL sees and edits the same shared data (no login).

## Notes

- No login/auth -- anyone with the link can view and edit data. Keep the
  Vercel URL private (do not share it publicly).
- Data also saves to the browser's localStorage as a backup, so a
  temporary network issue does not lose unsaved entries.
- To update the code later: edit files in GitHub, commit -- Vercel
  redeploys automatically on every push to the main branch.
- CSV import/export, all charts, client/business tracking -- everything
  works exactly like the original version, just backed by Supabase
  instead of local-only storage.
