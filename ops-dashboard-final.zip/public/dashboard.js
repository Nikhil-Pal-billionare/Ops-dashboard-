
(function () {
  "use strict";

  // ---------- state ----------
  var state = { clients: [], metrics: [], finance: [], audience: [] };
  var ui = { tab: "overview", period: "all", clientFilter: "all", bizFilter: "all", from: "", to: "" };
  var saveTimer = null;
  var LS_KEY = "ops_dashboard_v1";
  var SUPA_URL = window.__SUPA_URL__ || "";
  var SUPA_KEY = window.__SUPA_KEY__ || "";

  function uid() { return Math.random().toString(36).slice(2, 10); }
  function num(v) { var n = parseFloat(v); return isFinite(n) ? n : 0; }
  function fmt(n) {
    n = num(n);
    var a = Math.abs(n);
    if (a >= 10000000) return (n / 10000000).toFixed(2) + " Cr";
    if (a >= 100000) return (n / 100000).toFixed(2) + " L";
    if (a >= 1000) return (n / 1000).toFixed(1) + "K";
    return String(Math.round(n * 100) / 100);
  }
  function money(n) { return "Rs " + fmt(n); }
  function pct(n) { return (Math.round(n * 100) / 100) + "%"; }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function setStatus(t) { document.getElementById("status").textContent = t; }

  // ---------- persistence ----------
  function lsRead() {
    try { var raw = localStorage.getItem(LS_KEY); return raw ? JSON.parse(raw) : null; } catch (e) { return null; }
  }
  function lsWrite() {
    try { localStorage.setItem(LS_KEY, JSON.stringify(state)); } catch (e) { /* ignore */ }
  }
  function supaHeaders() {
    return {
      "Content-Type": "application/json",
      "apikey": SUPA_KEY,
      "Authorization": "Bearer " + SUPA_KEY,
      "Prefer": "resolution=merge-duplicates,return=minimal"
    };
  }
  function supaLoad() {
    if (!SUPA_URL || !SUPA_KEY) return Promise.resolve(null);
    return fetch(SUPA_URL + "/rest/v1/ops_state?id=eq.main&select=data", {
      headers: { "apikey": SUPA_KEY, "Authorization": "Bearer " + SUPA_KEY }
    }).then(function (res) {
      if (!res.ok) throw new Error("http " + res.status);
      return res.json();
    }).then(function (rows) {
      return (rows && rows[0] && rows[0].data) ? rows[0].data : null;
    });
  }
  function supaSave() {
    if (!SUPA_URL || !SUPA_KEY) return Promise.reject(new Error("no supabase config"));
    return fetch(SUPA_URL + "/rest/v1/ops_state?id=eq.main", {
      method: "PATCH",
      headers: supaHeaders(),
      body: JSON.stringify({ data: state, updated_at: new Date().toISOString() })
    }).then(function (res) {
      if (!res.ok) throw new Error("http " + res.status);
    });
  }
  function scheduleSave() {
    lsWrite();
    if (!SUPA_URL || !SUPA_KEY) { setStatus("Saved on this browser only (Supabase not configured)"); return; }
    clearTimeout(saveTimer);
    setStatus("Saving...");
    saveTimer = setTimeout(function () {
      supaSave().then(
        function () { setStatus("Saved"); },
        function (e) { setStatus("Cloud save failed (" + (e && e.message ? e.message : "error") + "). Saved on this browser."); }
      );
    }, 700);
  }
  function loadState(obj) {
    if (obj && typeof obj === "object") {
      state.clients = Array.isArray(obj.clients) ? obj.clients : [];
      state.metrics = Array.isArray(obj.metrics) ? obj.metrics : [];
      state.finance = Array.isArray(obj.finance) ? obj.finance : [];
      state.audience = Array.isArray(obj.audience) ? obj.audience : [];
    }
  }

  // ---------- date helpers ----------
  function todayStr() { return new Date().toISOString().slice(0, 10); }
  function addDays(dateStr, n) {
    var d = new Date(dateStr + "T00:00:00Z");
    d.setUTCDate(d.getUTCDate() + n);
    return d.toISOString().slice(0, 10);
  }
  // returns {from, to} as YYYY-MM-DD inclusive. "N days" = today and the N-1 days before it.
  function range() {
    if (ui.period === "custom") return { from: ui.from || "0000-00-00", to: ui.to || "9999-99-99" };
    if (ui.period === "all") return { from: "0000-00-00", to: "9999-99-99" };
    var n = parseInt(ui.period, 10);
    var t = todayStr();
    return { from: addDays(t, -(n - 1)), to: t };
  }
  function inRange(dateStr) {
    var r = range();
    return dateStr >= r.from && dateStr <= r.to;
  }
  function monthKey(dateStr) { return String(dateStr).slice(0, 7); }

  // ---------- aggregation ----------
  function filteredMetrics(clientId) {
    return state.metrics.filter(function (m) {
      return inRange(m.date) && (clientId === "all" || m.clientId === clientId);
    });
  }
  function sumMetrics(rows) {
    var t = { impressions: 0, clicks: 0, outbound: 0, saves: 0, engagement: 0 };
    rows.forEach(function (r) {
      t.impressions += num(r.impressions);
      t.clicks += num(r.clicks);
      t.outbound += num(r.outbound);
      t.saves += num(r.saves);
      t.engagement += num(r.engagement);
    });
    t.ctr = t.impressions ? (t.clicks / t.impressions) * 100 : 0;
    t.engRate = t.impressions ? (t.engagement / t.impressions) * 100 : 0;
    var days = {};
    rows.forEach(function (r) { days[r.date] = 1; });
    var dn = Object.keys(days).length;
    t.days = dn;
    t.avgImp = dn ? t.impressions / dn : 0;
    return t;
  }
  function filteredFinance() {
    return state.finance.filter(function (f) {
      return inRange(f.date) && (ui.bizFilter === "all" || (f.source || "Other") === ui.bizFilter);
    });
  }
  function bizList() {
    var seen = {}, out = [];
    state.finance.forEach(function (f) {
      var k = f.source || "Other";
      if (!seen[k]) { seen[k] = 1; out.push(k); }
    });
    return out.sort();
  }
  function sumFinance(rows) {
    var rev = 0, exp = 0;
    rows.forEach(function (r) {
      if (r.type === "revenue") rev += num(r.amount); else exp += num(r.amount);
    });
    return { revenue: rev, expenses: exp, profit: rev - exp, margin: rev ? ((rev - exp) / rev) * 100 : 0 };
  }
  function clientName(id) {
    for (var i = 0; i < state.clients.length; i++) if (state.clients[i].id === id) return state.clients[i].name;
    return "Unknown";
  }

  // ---------- charts (inline SVG) ----------
  function lineChart(series, height, extraHover) {
    // series: [{label, color, points:[{x:label, y:number}]}], shared x labels
    var W = 720, H = height || 240, pl = 44, pr = 12, pt = 10, pb = 26;
    var xs = [];
    series.forEach(function (s) { s.points.forEach(function (p) { if (xs.indexOf(p.x) < 0) xs.push(p.x); }); });
    xs.sort();
    if (!xs.length) return '<div class="empty">No data in this range yet.</div>';
    var maxY = 0;
    series.forEach(function (s) { s.points.forEach(function (p) { if (p.y > maxY) maxY = p.y; }); });
    if (maxY <= 0) maxY = 1;
    function X(i) { return pl + (xs.length === 1 ? (W - pl - pr) / 2 : (i * (W - pl - pr)) / (xs.length - 1)); }
    function Y(v) { return pt + (H - pt - pb) * (1 - v / maxY); }
    // payload for the hover tooltip: one entry per x, values for every series
    var payload = xs.map(function (x, i) {
      var vals = series.map(function (s) {
        var hit = null;
        s.points.forEach(function (p) { if (p.x === x) hit = p.y; });
        return { label: s.label, color: s.color, y: hit, py: hit == null ? null : Y(hit) };
      });
      (extraHover || []).forEach(function (s) {
        var hit = null;
        s.points.forEach(function (p) { if (p.x === x) hit = p.y; });
        vals.push({ label: s.label, color: s.color, y: hit, py: null, noDot: true });
      });
      return { x: x, px: X(i), v: vals };
    });
    var out = '<div class="chartwrap" data-kind="line" data-w="' + W + '" data-h="' + H + '" data-pt="' + pt + '" data-pb="' + pb + '" data-pts="' + esc(JSON.stringify(payload)) + '">';
    out += '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Trend chart">';
    for (var g = 0; g <= 4; g++) {
      var gv = (maxY * g) / 4, gy = Y(gv);
      out += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)" stroke-width="1"/>';
      out += '<text x="' + (pl - 6) + '" y="' + (gy + 4) + '" text-anchor="end">' + fmt(gv) + '</text>';
    }
    var step = Math.max(1, Math.ceil(xs.length / 6));
    xs.forEach(function (x, i) {
      if (i % step === 0 || i === xs.length - 1) {
        out += '<text x="' + X(i) + '" y="' + (H - 8) + '" text-anchor="middle">' + esc(x.slice(5)) + '</text>';
      }
    });
    series.forEach(function (s) {
      var map = {};
      s.points.forEach(function (p) { map[p.x] = p.y; });
      var d = "", started = false;
      xs.forEach(function (x, i) {
        if (map[x] == null) return;
        d += (started ? "L" : "M") + X(i).toFixed(1) + " " + Y(map[x]).toFixed(1) + " ";
        started = true;
      });
      out += '<path d="' + d + '" fill="none" stroke="' + s.color + '" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>';
      xs.forEach(function (x, i) {
        if (map[x] != null) out += '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(map[x]).toFixed(1) + '" r="3" fill="' + s.color + '"/>';
      });
    });
    out += '<line class="guide hidden-tip" x1="0" x2="0" y1="' + pt + '" y2="' + (H - pb) + '"/>';
    out += "</svg></div>";
    return out;
  }
  function barChart(groups, height) {
    // groups: [{x, a, b}] a=revenue b=expenses
    var W = 720, H = height || 240, pl = 44, pr = 12, pt = 10, pb = 26;
    if (!groups.length) return '<div class="empty">No data in this range yet.</div>';
    var maxY = 0;
    groups.forEach(function (g) { maxY = Math.max(maxY, g.a, g.b); });
    if (maxY <= 0) maxY = 1;
    var slot = (W - pl - pr) / groups.length, bw = Math.min(28, slot / 3);
    function Y(v) { return pt + (H - pt - pb) * (1 - v / maxY); }
    var bpayload = groups.map(function (gr, i) {
      var cx = pl + slot * i + slot / 2;
      return {
        x: gr.x, px: cx,
        v: [
          { label: "Revenue", color: "var(--gain)", y: gr.a, py: Y(gr.a), money: true },
          { label: "Expenses", color: "var(--loss)", y: gr.b, py: Y(gr.b), money: true },
          { label: "Profit", color: gr.a - gr.b >= 0 ? "var(--gain)" : "var(--loss)", y: gr.a - gr.b, py: null, money: true, noDot: true }
        ]
      };
    });
    var out = '<div class="chartwrap" data-kind="bar" data-w="' + W + '" data-h="' + H + '" data-pt="' + pt + '" data-pb="' + pb + '" data-pts="' + esc(JSON.stringify(bpayload)) + '">';
    out += '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Revenue and expenses by month">';
    for (var g = 0; g <= 4; g++) {
      var gv = (maxY * g) / 4, gy = Y(gv);
      out += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + gy + '" y2="' + gy + '" stroke="var(--line)"/>';
      out += '<text x="' + (pl - 6) + '" y="' + (gy + 4) + '" text-anchor="end">' + fmt(gv) + '</text>';
    }
    groups.forEach(function (gr, i) {
      var cx = pl + slot * i + slot / 2;
      out += '<rect x="' + (cx - bw - 1) + '" y="' + Y(gr.a) + '" width="' + bw + '" height="' + (H - pb - Y(gr.a)) + '" fill="var(--gain)"/>';
      out += '<rect x="' + (cx + 1) + '" y="' + Y(gr.b) + '" width="' + bw + '" height="' + (H - pb - Y(gr.b)) + '" fill="var(--loss)"/>';
      out += '<text x="' + cx + '" y="' + (H - 8) + '" text-anchor="middle">' + esc(gr.x.slice(2)) + '</text>';
    });
    out += '<line class="guide hidden-tip" x1="0" x2="0" y1="' + pt + '" y2="' + (H - pb) + '"/>';
    out += "</svg></div>";
    return out;
  }
  var GROWTH_SERIES = [
    ["impressions", "Impressions", "var(--ink)", true],
    ["clicks", "Pin clicks", "var(--pin)", true],
    ["outbound", "Outbound clicks", "#7C3AED", true],
    ["saves", "Saves", "#0E7490", true],
    ["engagement", "Engagement", "var(--gain)", true],
    ["totalAud", "Total audience", "#B45309", false],
    ["engagedAud", "Engaged audience", "#9D174D", false]
  ];
  // Shows only metrics that have data. Audience fields are daily-unique numbers: shown in hover, not drawn as summed lines.
  function growthChart(rows) {
    var drawn = [], hoverOnly = [];
    GROWTH_SERIES.forEach(function (g) {
      if (!hasSeries(rows, g[0])) return;
      var ser = { label: g[1], color: g[2], points: seriesFromMetrics(rows, g[0], true) };
      if (g[3]) drawn.push(ser); else hoverOnly.push(ser);
    });
    if (!drawn.length) return '<div class="empty">Is range mein abhi koi growth data nahi hai.</div>';
    var legend = '<div class="legend">' + drawn.map(function (d) { return '<span><i style="background:' + d.color + '"></i>' + esc(d.label) + "</span>"; }).join("") + "</div>";
    return legend + lineChart(drawn, 240, hoverOnly);
  }

  function seriesFromMetrics(rows, field) {
    var byDate = {}, seen = {};
    rows.forEach(function (r) {
      if (r[field] == null || r[field] === "") return;
      byDate[r.date] = (byDate[r.date] || 0) + num(r[field]);
      seen[r.date] = 1;
    });
    return Object.keys(byDate).sort().map(function (d) { return { x: d, y: byDate[d] }; });
  }
  // ---------- audience (unique people; NEVER summed across days) ----------
  // A record = {id, clientId, from, to, totalAud, engagedAud}. Pinterest gives one number for a whole date range.
  function audienceFor(clientId) {
    var r = range();
    var from = r.from, to = r.to;
    // exact match on the selected range wins
    var hits = state.audience.filter(function (a) {
      return (clientId === "all" || a.clientId === clientId) && a.from === from && a.to === to;
    });
    if (ui.period === "all" || ui.period === "custom" || !hits.length) {
      // for lifetime/custom (or when no exact match) use the record that best covers the range
      hits = state.audience.filter(function (a) {
        if (clientId !== "all" && a.clientId !== clientId) return false;
        if (ui.period === "all") return true;
        return a.from === from && a.to === to;
      });
    }
    return hits;
  }
  function hasSeries(rows, field) {
    for (var i = 0; i < rows.length; i++) if (rows[i][field] != null && rows[i][field] !== "") return true;
    return false;
  }
  function audienceCards(clientId) {
    var hits = audienceFor(clientId);
    if (!hits.length) {
      return '<div class="note">Is range ka audience number abhi nahi daala. Add data tab mein "Audience (range ka number)" mein daalo. (Audience unique log hote hain, isliye daily numbers jodke nahi nikaalta.)</div>';
    }
    // if several clients: we cannot add unique audiences across clients (people may overlap), so list them
    if (clientId === "all" && hits.length > 1) {
      var t = '<div class="tablewrap"><table><thead><tr><th>Client</th><th>Range</th><th>Total audience</th><th>Engaged audience</th></tr></thead><tbody>';
      hits.forEach(function (a) {
        t += "<tr><td>" + esc(clientName(a.clientId)) + "</td><td>" + esc(a.from + " to " + a.to) + "</td><td>" + fmtFull(a.totalAud) + "</td><td>" + fmtFull(a.engagedAud) + "</td></tr>";
      });
      return t + "</tbody></table></div><div class=\"note\">Clients ke audience ko jodta nahi, kyunki ek hi insaan kai clients ko dekh sakta hai.</div>";
    }
    var a = hits[hits.length - 1];
    return '<div class="hero">' +
      '<div class="stat"><span class="k">Total audience</span><span class="v">' + fmtFull(a.totalAud) + "</span></div>" +
      '<div class="stat"><span class="k">Engaged audience</span><span class="v">' + fmtFull(a.engagedAud) + "</span></div>" +
      '<div class="stat"><span class="k">Engaged share</span><span class="v pin">' + pct(a.totalAud ? (a.engagedAud / a.totalAud) * 100 : 0) + "</span></div>" +
      '</div><div class="note">Pinterest ka diya hua unique number: ' + esc(a.from + " to " + a.to) + "</div>";
  }

  // ---------- chart hover / touch tooltip ----------
  function fmtFull(n) { return Math.round(num(n)).toLocaleString("en-IN"); }
  function prettyDate(x) {
    if (/^\d{4}-\d{2}-\d{2}$/.test(x)) {
      var d = new Date(x + "T00:00:00Z");
      var days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      var mons = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      return days[d.getUTCDay()] + ", " + d.getUTCDate() + " " + mons[d.getUTCMonth()] + " " + d.getUTCFullYear();
    }
    if (/^\d{4}-\d{2}$/.test(x)) {
      var m = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      return m[parseInt(x.slice(5), 10) - 1] + " " + x.slice(0, 4);
    }
    return x;
  }
  function initCharts(root) {
    root.querySelectorAll(".chartwrap").forEach(function (wrap) {
      var pts;
      try { pts = JSON.parse(wrap.getAttribute("data-pts")); } catch (e) { return; }
      if (!pts || !pts.length) return;
      var W = parseFloat(wrap.getAttribute("data-w")), H = parseFloat(wrap.getAttribute("data-h"));
      var svg = wrap.querySelector("svg");
      var guide = svg.querySelector(".guide");
      var NS = "http://www.w3.org/2000/svg";
      var dots = [];
      var tip = document.createElement("div");
      tip.className = "tip hidden-tip";
      tip.setAttribute("role", "status");
      wrap.appendChild(tip);

      function clearDots() { dots.forEach(function (d) { if (d.parentNode) d.parentNode.removeChild(d); }); dots = []; }
      function hide() { tip.classList.add("hidden-tip"); guide.classList.add("hidden-tip"); clearDots(); }

      function show(clientX) {
        var box = svg.getBoundingClientRect();
        if (!box.width) return;
        var sx = (clientX - box.left) * (W / box.width);
        var best = 0, bd = Infinity;
        pts.forEach(function (p, i) { var dd = Math.abs(p.px - sx); if (dd < bd) { bd = dd; best = i; } });
        var pt = pts[best];

        guide.setAttribute("x1", pt.px); guide.setAttribute("x2", pt.px);
        guide.classList.remove("hidden-tip");
        clearDots();
        pt.v.forEach(function (v) {
          if (v.y == null || v.py == null || v.noDot) return;
          var c = document.createElementNS(NS, "circle");
          c.setAttribute("class", "hdot");
          c.setAttribute("cx", pt.px); c.setAttribute("cy", v.py); c.setAttribute("r", 5);
          c.setAttribute("fill", v.color);
          svg.appendChild(c); dots.push(c);
        });

        var h = '<div class="td">' + esc(prettyDate(pt.x)) + "</div>";
        pt.v.forEach(function (v) {
          var val = v.y == null ? "no data" : (v.money ? "Rs " + fmtFull(v.y) : fmtFull(v.y));
          h += '<div class="tr"><span><i style="background:' + v.color + '"></i>' + esc(v.label) + "</span><b>" + esc(val) + "</b></div>";
        });
        tip.innerHTML = h;
        tip.classList.remove("hidden-tip");

        // position the tooltip next to the guide line, flip near the edges
        var px = (pt.px / W) * box.width;
        var tw = tip.offsetWidth, th = tip.offsetHeight;
        var left = px + 14;
        if (left + tw > box.width) left = px - tw - 14;
        if (left < 0) left = 0;
        var top = 8;
        if (top + th > (H / W) * box.width) top = 0;
        tip.style.left = left + "px";
        tip.style.top = top + "px";
      }

      wrap.addEventListener("mousemove", function (e) { show(e.clientX); });
      wrap.addEventListener("mouseleave", hide);
      wrap.addEventListener("touchstart", function (e) { if (e.touches[0]) show(e.touches[0].clientX); }, { passive: true });
      wrap.addEventListener("touchmove", function (e) { if (e.touches[0]) show(e.touches[0].clientX); }, { passive: true });
      wrap.addEventListener("touchend", function () { setTimeout(hide, 1800); });
    });
  }

  // ---------- views ----------
  function periodSelect() {
    var opts = [["1", "Today"], ["3", "Last 3 days"], ["7", "Last 7 days"], ["30", "Last 30 days"], ["60", "Last 60 days"], ["90", "Last 90 days"], ["all", "Lifetime"], ["custom", "Custom range"]];
    var h = '<select id="period" aria-label="Time range">' + opts.map(function (o) {
      return '<option value="' + o[0] + '"' + (ui.period === o[0] ? " selected" : "") + ">" + o[1] + "</option>";
    }).join("") + "</select>";
    if (ui.period === "custom") {
      h += '<input type="date" id="rFrom" value="' + esc(ui.from) + '" aria-label="From date">' +
           '<input type="date" id="rTo" value="' + esc(ui.to) + '" aria-label="To date">';
    }
    return h;
  }
  function bindPeriod(root) {
    var el = root.querySelector("#period");
    if (el) el.addEventListener("change", function () { ui.period = el.value; renderAll(); });
    var f = root.querySelector("#rFrom"), t = root.querySelector("#rTo");
    if (f) f.addEventListener("change", function () { ui.from = f.value; renderAll(); });
    if (t) t.addEventListener("change", function () { ui.to = t.value; renderAll(); });
  }
  function rangeLabel() {
    var r = range();
    if (ui.period === "all") return "Lifetime";
    return r.from + " to " + r.to;
  }
  function bizSelect() {
    return '<select id="bizPick" aria-label="Business">' +
      '<option value="all">All businesses</option>' +
      bizList().map(function (b) { return '<option value="' + esc(b) + '"' + (ui.bizFilter === b ? " selected" : "") + ">" + esc(b) + "</option>"; }).join("") +
      "</select>";
  }
  function bindBiz(root) {
    var el = root.querySelector("#bizPick");
    if (el) el.addEventListener("change", function () { ui.bizFilter = el.value; renderAll(); });
  }

  function renderOverview() {
    var root = document.getElementById("tab-overview");
    var mt = sumMetrics(filteredMetrics("all"));
    var fn = sumFinance(filteredFinance());
    var h = '<div class="toolbar">' + periodSelect() + '<span class="note">' + esc(rangeLabel()) + "</span></div>";
    h += '<h3 style="margin-top:0">Client growth (all clients combined)</h3>';
    h += '<div class="hero">' +
      '<div class="stat"><span class="k">Total impressions</span><span class="v">' + fmt(mt.impressions) + "</span></div>" +
      '<div class="stat"><span class="k">Total clicks</span><span class="v">' + fmt(mt.clicks) + "</span></div>" +
      '<div class="stat"><span class="k">Outbound clicks</span><span class="v">' + fmt(mt.outbound) + "</span></div>" +
      '<div class="stat"><span class="k">Total engagement</span><span class="v">' + fmt(mt.engagement) + "</span></div>" +
      '<div class="stat"><span class="k">Total saves</span><span class="v">' + fmt(mt.saves) + "</span></div>" +
      '<div class="stat"><span class="k">Avg impressions per day</span><span class="v">' + fmt(mt.avgImp) + "</span></div>" +
      '<div class="stat"><span class="k">CTR / Engagement rate</span><span class="v pin">' + pct(mt.ctr) + " / " + pct(mt.engRate) + "</span></div>" +
      "</div>";
    h += '<h3>Audience (unique log)</h3>' + audienceCards("all");
    var rows = filteredMetrics("all");
    h += '<div class="chartbox"><h2>Growth over time (hover karo daily numbers ke liye)</h2>' + growthChart(rows) + "</div>";

    h += '<h3>Business finance</h3>';
    h += '<div class="hero">' +
      '<div class="stat"><span class="k">Revenue</span><span class="v gain">' + money(fn.revenue) + "</span></div>" +
      '<div class="stat"><span class="k">Expenses</span><span class="v loss">' + money(fn.expenses) + "</span></div>" +
      '<div class="stat"><span class="k">Profit (margin ' + pct(fn.margin) + ')</span><span class="v ' + (fn.profit >= 0 ? "gain" : "loss") + '">' + money(fn.profit) + "</span></div>" +
      "</div>";
    root.innerHTML = h;
    bindPeriod(root);
  }

  function renderClients() {
    var root = document.getElementById("tab-clients");
    var h = '<div class="toolbar">' + periodSelect() + '<span class="note">' + esc(rangeLabel()) + "</span></div>";
    if (!state.clients.length) {
      h += '<div class="empty">Abhi koi client nahi hai. "Add data" tab mein pehla client add karo.</div>';
      root.innerHTML = h; bindPeriod(root); return;
    }
    var totalRows = filteredMetrics("all");
    var tot = sumMetrics(totalRows);
    h += '<div class="tablewrap"><table><thead><tr><th>Client</th><th>Impressions</th><th>Pin clicks</th><th>Outbound</th><th>Saves</th><th>Engagement</th><th>CTR</th><th>Eng. rate</th><th>Avg imp/day</th></tr></thead><tbody>';
    state.clients.forEach(function (c) {
      var r = filteredMetrics(c.id);
      var s = sumMetrics(r);
      h += "<tr><td>" + esc(c.name) + "</td><td>" + fmt(s.impressions) + "</td><td>" + fmt(s.clicks) + "</td><td>" + fmt(s.outbound) + "</td><td>" + fmt(s.saves) + "</td><td>" + fmt(s.engagement) + "</td><td>" + pct(s.ctr) + "</td><td>" + pct(s.engRate) + "</td><td>" + fmt(s.avgImp) + "</td></tr>";
    });
    h += '<tr class="total"><td>All clients</td><td>' + fmt(tot.impressions) + "</td><td>" + fmt(tot.clicks) + "</td><td>" + fmt(tot.outbound) + "</td><td>" + fmt(tot.saves) + "</td><td>" + fmt(tot.engagement) + "</td><td>" + pct(tot.ctr) + "</td><td>" + pct(tot.engRate) + "</td><td>" + fmt(tot.avgImp) + "</td></tr>";
    h += "</tbody></table></div>";

    h += '<div class="toolbar"><select id="clientPick" aria-label="Client">' +
      '<option value="all">All clients</option>' +
      state.clients.map(function (c) { return '<option value="' + esc(c.id) + '"' + (ui.clientFilter === c.id ? " selected" : "") + ">" + esc(c.name) + "</option>"; }).join("") +
      "</select></div>";
    var rows = filteredMetrics(ui.clientFilter);
    h += '<h3>Audience (unique log): ' + (ui.clientFilter === "all" ? "sab clients" : esc(clientName(ui.clientFilter))) + "</h3>" + audienceCards(ui.clientFilter);
    h += '<div class="chartbox"><h2>' + (ui.clientFilter === "all" ? "All clients" : esc(clientName(ui.clientFilter))) + ': growth over time</h2>' + growthChart(rows) + "</div>";
    root.innerHTML = h;
    bindPeriod(root);
    var pick = root.querySelector("#clientPick");
    if (pick) pick.addEventListener("change", function () { ui.clientFilter = pick.value; renderClients(); initCharts(document.getElementById("tab-clients")); });
  }

  function renderBusiness() {
    var root = document.getElementById("tab-business");
    var rows = filteredFinance();
    var fn = sumFinance(rows);
    var h = '<div class="toolbar">' + periodSelect() + bizSelect() + '<span class="note">' + esc(rangeLabel()) + "</span></div>";
    h += '<div class="hero">' +
      '<div class="stat"><span class="k">Revenue</span><span class="v gain">' + money(fn.revenue) + "</span></div>" +
      '<div class="stat"><span class="k">Expenses</span><span class="v loss">' + money(fn.expenses) + "</span></div>" +
      '<div class="stat"><span class="k">Profit</span><span class="v ' + (fn.profit >= 0 ? "gain" : "loss") + '">' + money(fn.profit) + "</span></div>" +
      "</div>";
    var byMonth = {};
    rows.forEach(function (r) {
      var k = monthKey(r.date);
      byMonth[k] = byMonth[k] || { x: k, a: 0, b: 0 };
      if (r.type === "revenue") byMonth[k].a += num(r.amount); else byMonth[k].b += num(r.amount);
    });
    var groups = Object.keys(byMonth).sort().map(function (k) { return byMonth[k]; });
    h += '<div class="chartbox"><h2>Revenue vs expenses by month</h2>' +
      '<div class="legend"><span><i style="background:var(--gain)"></i>Revenue</span><span><i style="background:var(--loss)"></i>Expenses</span></div>' +
      barChart(groups) + "</div>";

    var bySrc = {};
    rows.forEach(function (r) {
      var k = (r.source || "Other");
      bySrc[k] = bySrc[k] || { rev: 0, exp: 0 };
      if (r.type === "revenue") bySrc[k].rev += num(r.amount); else bySrc[k].exp += num(r.amount);
    });
    var keys = Object.keys(bySrc).sort();
    if (keys.length) {
      h += '<div class="tablewrap"><table><thead><tr><th>Business / source</th><th>Revenue</th><th>Expenses</th><th>Profit</th></tr></thead><tbody>';
      keys.forEach(function (k) {
        var p = bySrc[k].rev - bySrc[k].exp;
        h += "<tr><td>" + esc(k) + "</td><td>" + money(bySrc[k].rev) + "</td><td>" + money(bySrc[k].exp) + '</td><td style="color:' + (p >= 0 ? "var(--gain)" : "var(--loss)") + '">' + money(p) + "</td></tr>";
      });
      h += "</tbody></table></div>";
    }
    root.innerHTML = h;
    bindPeriod(root);
    bindBiz(root);
  }

  function renderData() {
    var root = document.getElementById("tab-data");
    var h = "";
    h += "<h3 style=\"margin-top:0\">1. Add a client</h3>";
    h += '<div class="toolbar"><input id="newClient" placeholder="Client name" aria-label="Client name"><button class="btn primary" id="addClient">Add client</button></div>';
    if (state.clients.length) {
      h += '<div class="note">Clients: ' + state.clients.map(function (c) {
        return esc(c.name) + ' <button class="rowbtn" data-delclient="' + esc(c.id) + '" aria-label="Delete ' + esc(c.name) + '">x</button>';
      }).join(" &nbsp; ") + "</div>";
    }

    h += "<h3>2. Add client growth entry</h3>";
    h += '<div class="formgrid">' +
      '<label>Client<select id="mClient">' + state.clients.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.name) + "</option>"; }).join("") + "</select></label>" +
      '<label>Date<input id="mDate" type="date" value="' + todayStr() + '"></label>' +
      '<label>Impressions<input id="mImp" type="number" min="0" inputmode="numeric"></label>' +
      '<label>Clicks<input id="mClk" type="number" min="0" inputmode="numeric"></label>' +
      '<label>Saves<input id="mSav" type="number" min="0" inputmode="numeric"></label>' +
      '<label>Outbound clicks<input id="mOut" type="number" min="0" inputmode="numeric"></label>' +
      '<label>Engagement<input id="mEng" type="number" min="0" inputmode="numeric"></label>' +
      '<label>Total audience (us din)<input id="mTA" type="number" min="0" inputmode="numeric"></label>' +
      '<label>Engaged audience (us din)<input id="mEA" type="number" min="0" inputmode="numeric"></label>' +
      "</div>";
    h += '<button class="btn primary" id="addMetric">Save entry</button>';

    h += "<h3>2b. Audience (range ka number)</h3>";
    h += '<div class="note">Pinterest Analytics mein Total audience aur Engaged audience poori date range ka ek number hota hai (unique log). Wo yahan daalo. Isko din-ba-din jodna galat hai.</div>';
    h += '<div class="formgrid">' +
      '<label>Client<select id="aClient">' + state.clients.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.name) + "</option>"; }).join("") + "</select></label>" +
      '<label>From date<input id="aFrom" type="date"></label>' +
      '<label>To date<input id="aTo" type="date" value="' + todayStr() + '"></label>' +
      '<label>Total audience<input id="aTotal" type="number" min="0" inputmode="numeric"></label>' +
      '<label>Engaged audience<input id="aEng" type="number" min="0" inputmode="numeric"></label>' +
      "</div>";
    h += '<button class="btn primary" id="addAud">Save audience</button>';
    if (state.audience.length) {
      h += '<div class="note" style="margin-top:10px">Saved audience records: ' + state.audience.map(function (a) {
        return esc(clientName(a.clientId)) + " " + esc(a.from) + " to " + esc(a.to) + ": " + fmtFull(a.totalAud) + " / " + fmtFull(a.engagedAud) + ' <button class="rowbtn" data-delaud="' + esc(a.id) + '" aria-label="Delete audience record">x</button>';
      }).join(" &nbsp; | &nbsp; ") + "</div>";
    }

    h += "<h3>3. Add revenue or expense</h3>";
    h += '<div class="formgrid">' +
      '<label>Type<select id="fType"><option value="revenue">Revenue</option><option value="expense">Expense</option></select></label>' +
      '<label>Date<input id="fDate" type="date" value="' + todayStr() + '"></label>' +
      '<label>Amount (Rs)<input id="fAmt" type="number" min="0" inputmode="decimal"></label>' +
      '<label>Business / source<input id="fSrc" placeholder="GrowMyPin, MoonWeaves..."></label>' +
      "</div>";
    h += '<button class="btn primary" id="addFin">Save entry</button>';

    h += "<h3>4. Import CSV</h3>";
    h += '<div class="note">Client growth CSV: client,date + jitne metric ho (impressions, clicks, outbound clicks, saves, engagement, total audience, engaged audience). Jo column CSV mein nahi hai wo purana data nahi todta. Date YYYY-MM-DD.<br>Finance CSV columns: type,date,amount,source (type is revenue or expense).</div>';
    h += '<div class="toolbar"><label style="flex-direction:row;align-items:center;gap:8px">Growth CSV <input type="file" id="csvMetrics" accept=".csv,text/csv"></label>' +
      '<label style="flex-direction:row;align-items:center;gap:8px">Finance CSV <input type="file" id="csvFin" accept=".csv,text/csv"></label></div>';

    h += "<h3>5. Backup</h3>";
    h += '<div class="toolbar"><button class="btn" id="expMetrics">Export growth CSV</button><button class="btn" id="expFin">Export finance CSV</button></div>';
    h += '<div class="note">Total entries: ' + state.metrics.length + " growth, " + state.finance.length + " finance.</div>";

    h += '<h3>Recent entries</h3>';
    var recentM = state.metrics.slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; }).slice(0, 8);
    var recentF = state.finance.slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; }).slice(0, 8);
    if (!recentM.length && !recentF.length) {
      h += '<div class="empty">Abhi koi entry nahi hai.</div>';
    } else {
      h += '<div class="tablewrap"><table><thead><tr><th>Entry</th><th>Date</th><th>Detail</th><th></th></tr></thead><tbody>';
      recentM.forEach(function (m) {
        h += "<tr><td>" + esc(clientName(m.clientId)) + "</td><td>" + esc(m.date) + "</td><td>imp " + fmt(m.impressions) + ", clk " + fmt(m.clicks) + ", out " + fmt(m.outbound) + ", sav " + fmt(m.saves) + ", eng " + fmt(m.engagement) + '</td><td><button class="rowbtn" data-delmetric="' + esc(m.id) + '" aria-label="Delete entry">x</button></td></tr>';
      });
      recentF.forEach(function (f) {
        h += "<tr><td>" + esc(f.source || "Other") + "</td><td>" + esc(f.date) + "</td><td>" + esc(f.type) + " " + money(f.amount) + '</td><td><button class="rowbtn" data-delfin="' + esc(f.id) + '" aria-label="Delete entry">x</button></td></tr>';
      });
      h += "</tbody></table></div>";
    }
    root.innerHTML = h;
    bindData(root);
  }

  // ---------- upsert (dedupe) ----------
  // growth: one row per client + date. finance: identical type+date+amount+source is a duplicate.
  var METRIC_FIELDS = ["impressions", "clicks", "outbound", "saves", "engagement", "totalAud", "engagedAud"];
  // rec only carries the fields that were provided (others are undefined). Provided fields overwrite;
  // missing fields keep their old value, so separate exports (impressions, saves, audience...) can be merged.
  function upsertMetric(rec) {
    for (var i = 0; i < state.metrics.length; i++) {
      var m = state.metrics[i];
      if (m.clientId === rec.clientId && m.date === rec.date) {
        METRIC_FIELDS.forEach(function (f) { if (rec[f] !== undefined) m[f] = rec[f]; });
        return "updated";
      }
    }
    var fresh = { id: rec.id, clientId: rec.clientId, date: rec.date };
    METRIC_FIELDS.forEach(function (f) { if (rec[f] !== undefined) fresh[f] = rec[f]; });
    state.metrics.push(fresh);
    return "added";
  }
  function addFinanceUnique(rec) {
    for (var i = 0; i < state.finance.length; i++) {
      var f = state.finance[i];
      if (f.type === rec.type && f.date === rec.date && num(f.amount) === num(rec.amount) && (f.source || "Other") === (rec.source || "Other")) {
        return "skipped";
      }
    }
    state.finance.push(rec);
    return "added";
  }

  // ---------- data actions ----------
  function bindData(root) {
    root.querySelector("#addClient").addEventListener("click", function () {
      var el = root.querySelector("#newClient");
      var name = el.value.trim();
      if (!name) { el.focus(); return; }
      state.clients.push({ id: uid(), name: name });
      scheduleSave(); renderAll();
    });
    root.querySelector("#addMetric").addEventListener("click", function () {
      var cid = root.querySelector("#mClient").value;
      if (!cid) { alert("Pehle client add karo."); return; }
      var date = root.querySelector("#mDate").value || todayStr();
      var mrec = { id: uid(), clientId: cid, date: date };
      [["impressions", "#mImp"], ["clicks", "#mClk"], ["outbound", "#mOut"], ["saves", "#mSav"], ["engagement", "#mEng"], ["totalAud", "#mTA"], ["engagedAud", "#mEA"]].forEach(function (pair) {
        var el = root.querySelector(pair[1]);
        if (el && String(el.value).trim() !== "") mrec[pair[0]] = num(el.value);
      });
      var res = upsertMetric(mrec);
      scheduleSave(); renderAll();
      if (res === "updated") setStatus("Is client ki us date ki entry update ho gayi (double nahi hui)");
    });
    root.querySelector("#addAud").addEventListener("click", function () {
      var cid = root.querySelector("#aClient").value;
      if (!cid) { alert("Pehle client add karo."); return; }
      var from = root.querySelector("#aFrom").value, to = root.querySelector("#aTo").value;
      if (!from || !to || from > to) { alert("From aur To date sahi daalo (From, To se pehle honi chahiye)."); return; }
      var ta = String(root.querySelector("#aTotal").value).trim(), ea = String(root.querySelector("#aEng").value).trim();
      if (ta === "" && ea === "") { root.querySelector("#aTotal").focus(); return; }
      var hit = null;
      state.audience.forEach(function (a) { if (a.clientId === cid && a.from === from && a.to === to) hit = a; });
      if (!hit) { hit = { id: uid(), clientId: cid, from: from, to: to }; state.audience.push(hit); }
      if (ta !== "") hit.totalAud = num(ta);
      if (ea !== "") hit.engagedAud = num(ea);
      scheduleSave(); renderAll();
    });
    root.querySelectorAll("[data-delaud]").forEach(function (b) {
      b.addEventListener("click", function () {
        var id = b.getAttribute("data-delaud");
        state.audience = state.audience.filter(function (a) { return a.id !== id; });
        scheduleSave(); renderAll();
      });
    });
    root.querySelector("#addFin").addEventListener("click", function () {
      var amt = num(root.querySelector("#fAmt").value);
      if (amt <= 0) { root.querySelector("#fAmt").focus(); return; }
      var fres = addFinanceUnique({
        id: uid(), type: root.querySelector("#fType").value,
        date: root.querySelector("#fDate").value || todayStr(),
        amount: amt, source: root.querySelector("#fSrc").value.trim() || "Other"
      });
      scheduleSave(); renderAll();
      if (fres === "skipped") setStatus("Ye same entry pehle se hai, skip ki");
    });
    root.querySelectorAll("[data-delclient]").forEach(function (b) {
      b.addEventListener("click", function () {
        var id = b.getAttribute("data-delclient");
        if (!confirm("Is client aur uski saari growth entries delete karni hain?")) return;
        state.clients = state.clients.filter(function (c) { return c.id !== id; });
        state.metrics = state.metrics.filter(function (m) { return m.clientId !== id; });
        state.audience = state.audience.filter(function (a) { return a.clientId !== id; });
        scheduleSave(); renderAll();
      });
    });
    root.querySelectorAll("[data-delmetric]").forEach(function (b) {
      b.addEventListener("click", function () {
        var id = b.getAttribute("data-delmetric");
        state.metrics = state.metrics.filter(function (m) { return m.id !== id; });
        scheduleSave(); renderAll();
      });
    });
    root.querySelectorAll("[data-delfin]").forEach(function (b) {
      b.addEventListener("click", function () {
        var id = b.getAttribute("data-delfin");
        state.finance = state.finance.filter(function (f) { return f.id !== id; });
        scheduleSave(); renderAll();
      });
    });
    root.querySelector("#csvMetrics").addEventListener("change", function (e) { importCsv(e.target.files[0], "metrics"); e.target.value = ""; });
    root.querySelector("#csvFin").addEventListener("change", function (e) { importCsv(e.target.files[0], "finance"); e.target.value = ""; });
    root.querySelector("#expMetrics").addEventListener("click", function () { exportCsv("metrics"); });
    root.querySelector("#expFin").addEventListener("click", function () { exportCsv("finance"); });
  }

  // ---------- CSV ----------
  function parseCsv(text) {
    var rows = [], row = [], cur = "", q = false;
    for (var i = 0; i < text.length; i++) {
      var ch = text[i];
      if (q) {
        if (ch === '"' && text[i + 1] === '"') { cur += '"'; i++; }
        else if (ch === '"') q = false;
        else cur += ch;
      } else if (ch === '"') q = true;
      else if (ch === ",") { row.push(cur); cur = ""; }
      else if (ch === "\n" || ch === "\r") {
        if (ch === "\r" && text[i + 1] === "\n") i++;
        row.push(cur); cur = "";
        if (row.length > 1 || row[0] !== "") rows.push(row);
        row = [];
      } else cur += ch;
    }
    if (cur !== "" || row.length) { row.push(cur); rows.push(row); }
    return rows;
  }
  function csvCell(v) {
    v = String(v == null ? "" : v);
    return /[",\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  function normDate(s) {
    s = String(s || "").trim();
    var m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
    if (m) return m[1] + "-" + ("0" + m[2]).slice(-2) + "-" + ("0" + m[3]).slice(-2);
    var d = new Date(s);
    return isNaN(d.getTime()) ? "" : d.toISOString().slice(0, 10);
  }
  function importCsv(file, kind) {
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      var rows = parseCsv(String(reader.result));
      if (rows.length < 2) { alert("CSV mein data rows nahi mile."); return; }
      var head = rows[0].map(function (h) { return h.trim().toLowerCase(); });
      function col(name) { return head.indexOf(name); }
      var added = 0, updated = 0, skipped = 0;
      if (kind === "metrics") {
        var ci = col("client"), di = col("date");
        if (ci < 0 || di < 0) { alert("CSV mein 'client' aur 'date' columns chahiye."); return; }
        rows.slice(1).forEach(function (r) {
          var name = (r[ci] || "").trim(), date = normDate(r[di]);
          if (!name || !date) { skipped++; return; }
          var client = state.clients.filter(function (c) { return c.name.toLowerCase() === name.toLowerCase(); })[0];
          if (!client) { client = { id: uid(), name: name }; state.clients.push(client); }
          var rec = { id: uid(), clientId: client.id, date: date };
          var map = { impressions: "impressions", clicks: "clicks", outbound: "outbound clicks", saves: "saves", engagement: "engagement", totalAud: "total audience", engagedAud: "engaged audience" };
          var any = false;
          Object.keys(map).forEach(function (k) {
            var ix = col(map[k]);
            if (ix < 0) ix = col(k.toLowerCase());
            if (ix >= 0 && String(r[ix] == null ? "" : r[ix]).trim() !== "") { rec[k] = num(r[ix]); any = true; }
          });
          if (!any) { skipped++; return; }
          var mres = upsertMetric(rec);
          if (mres === "updated") updated++; else added++;
        });
      } else {
        var ti = col("type"), dt = col("date"), ai = col("amount");
        if (ti < 0 || dt < 0 || ai < 0) { alert("CSV mein 'type', 'date', 'amount' columns chahiye."); return; }
        rows.slice(1).forEach(function (r) {
          var type = (r[ti] || "").trim().toLowerCase(), date = normDate(r[dt]), amt = num(r[ai]);
          if ((type !== "revenue" && type !== "expense") || !date || amt <= 0) { skipped++; return; }
          var fr = addFinanceUnique({ id: uid(), type: type, date: date, amount: amt, source: (r[col("source")] || "Other").trim() || "Other" });
          if (fr === "skipped") skipped++; else added++;
        });
      }
      scheduleSave(); renderAll();
      alert(added + " nayi rows add hui, " + updated + " purani update hui, " + skipped + " skip hui (duplicate ya galat).");
    };
    reader.readAsText(file);
  }
  function exportCsv(kind) {
    var lines;
    if (kind === "metrics") {
      lines = ["client,date,impressions,clicks,outbound clicks,saves,engagement,total audience,engaged audience"];
      state.metrics.forEach(function (m) {
        lines.push([clientName(m.clientId), m.date, m.impressions, m.clicks, m.outbound, m.saves, m.engagement, m.totalAud, m.engagedAud].map(function (v) { return v == null ? "" : v; }).map(csvCell).join(","));
      });
    } else {
      lines = ["type,date,amount,source"];
      state.finance.forEach(function (f) {
        lines.push([f.type, f.date, f.amount, f.source].map(csvCell).join(","));
      });
    }
    var data = lines.join("\n");
    var filename = (kind === "metrics" ? "client-growth" : "finance") + "-" + todayStr() + ".csv";
    try {
      var blob = new Blob([data], { type: "text/csv;charset=utf-8;" });
      var a = document.createElement("a");
      var blobUrl = URL.createObjectURL(blob);
      a.href = blobUrl; a.download = filename;
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(blobUrl); }, 1000);
    } catch (e) { setStatus("Download failed"); }
  }

  // ---------- render / tabs ----------
  function renderAll() {
    renderOverview(); renderClients(); renderBusiness(); renderData();
    initCharts(document);
  }
  document.getElementById("tabs").addEventListener("click", function (e) {
    var b = e.target.closest("button[data-tab]");
    if (!b) return;
    ui.tab = b.getAttribute("data-tab");
    document.querySelectorAll("#tabs button").forEach(function (x) {
      x.setAttribute("aria-selected", x === b ? "true" : "false");
    });
    ["overview", "clients", "business", "data"].forEach(function (t) {
      document.getElementById("tab-" + t).classList.toggle("hidden", t !== ui.tab);
    });
  });

  // ---------- boot ----------
  loadState(lsRead());
  renderAll();
  setStatus(state.clients.length || state.metrics.length || state.finance.length ? "Loaded from this browser" : "Empty. Start from the Add data tab.");

  if (SUPA_URL && SUPA_KEY) {
    supaLoad().then(function (cloud) {
      if (cloud) {
        var hasLocal = state.clients.length || state.metrics.length || state.finance.length;
        var cloudCount = (cloud.metrics || []).length + (cloud.finance || []).length;
        var localCount = state.metrics.length + state.finance.length;
        if (!hasLocal || cloudCount >= localCount) {
          loadState(cloud); lsWrite(); renderAll();
        }
      }
      setStatus("Cloud sync on");
      if (state.clients.length || state.metrics.length || state.finance.length) scheduleSave();
    }, function () { setStatus("Cloud sync unavailable. Using this browser."); });
  }
})();
