export default function Page() {
  var supaUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
  var supaKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";
  var envScript = "window.__SUPA_URL__ = " + JSON.stringify(supaUrl) + "; window.__SUPA_KEY__ = " + JSON.stringify(supaKey) + ";";

  return (
    <div>
      <link rel="stylesheet" href="/dashboard.css" />
      <div className="wrap">
        <header>
          <h1>Ops Dashboard</h1>
          <span className="status" id="status">Loading data...</span>
        </header>

        <nav role="tablist" id="tabs">
          <button role="tab" data-tab="overview" aria-selected="true">Overview</button>
          <button role="tab" data-tab="clients" aria-selected="false">Clients</button>
          <button role="tab" data-tab="business" aria-selected="false">Business</button>
          <button role="tab" data-tab="data" aria-selected="false">Add data</button>
        </nav>

        <section id="tab-overview"></section>
        <section id="tab-clients" className="hidden"></section>
        <section id="tab-business" className="hidden"></section>
        <section id="tab-data" className="hidden"></section>
      </div>

      <script dangerouslySetInnerHTML={{ __html: envScript }} />
      <script src="/dashboard.js" defer></script>
    </div>
  );
}
